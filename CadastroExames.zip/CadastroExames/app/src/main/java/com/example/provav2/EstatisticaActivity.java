package com.example.provav2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import org.w3c.dom.Text;

public class EstatisticaActivity extends AppCompatActivity {

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estatistica);

        //variaveis de cada categoria
        TextView tvTotalCOVIDPositivo = findViewById(R.id.tvTotalCOVIDPositivo);
        TextView tvJovensCOVIDPositivo = findViewById(R.id.tvJovensCOVIDPositivo);
        TextView tvAdultosCOVIDPositivo = findViewById(R.id.tvAdultosCOVIDPositivo);
        TextView tvIdososCOVIDPositivo = findViewById(R.id.tvIdososCOVIDPositivo);

        //utilizando o registro do intent
        Intent intent = this.getIntent();

        int pTotalCOVIDPositivo = intent.getIntExtra("TotalCOVIDPositivo", 0);
        int pJovensCOVIDPositivo = intent.getIntExtra("JovensCOVIDPositivo", 0);
        int pAdultosCOVIDPositivo = intent.getIntExtra("AdultosCOVIDPositivo", 0);
        int pIdososCOVIDPositivo = intent.getIntExtra("IdososCOVIDPositivo", 0);

        //configurando os campos
        tvTotalCOVIDPositivo.setText(String.format("Total de cadastrados com COVID: %d", pTotalCOVIDPositivo));
        tvJovensCOVIDPositivo.setText(String.format(" \t Jovens com Covid: %d", pJovensCOVIDPositivo));
        tvAdultosCOVIDPositivo.setText(String.format("\t Adultos com COVID: %d", pAdultosCOVIDPositivo));
        tvIdososCOVIDPositivo.setText(String.format("\t Idosos com COVID: %d", pIdososCOVIDPositivo));

    }
}