package com.example.provav2;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyAdapter extends ArrayAdapter<Componentes> {
    //declarando:
    private Context context;
    private int resource; //o arquivo de layout
    private ArrayList<Componentes> componente;
    public MyAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Componentes> componente) {
        super(context, resource, componente);
        
        this.context = context;
        this.resource = resource; 
        this.componente = componente;
    }
    //Inflar
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        ViewHolder holder;
        //se o convert for nulo,nenhuma view foi criada
        if (convertView == null){
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            convertView = inflater.inflate(resource, parent, false);
            
            holder = new ViewHolder();
            holder.txtNome = convertView.findViewById(R.id.tvNome);
            holder.txtIdade = convertView.findViewById(R.id.tvIdade);
            holder.txtSexo = convertView.findViewById(R.id.tvSexo);
            holder.imgImage = convertView.findViewById(R.id.image);

            holder.layout_ItensReduzidos = convertView.findViewById(R.id.layoutItensReduzidos);
            
            convertView.setTag(holder);
            
        }
        //se nao tiver nulo -> view ta pronta:
        else {
            holder = (ViewHolder)convertView.getTag();
        }
        
        //colocar os valores na posição que a lista está passando
        Componentes componentes = componente.get(position);
        
        //configurando o viewHolder
        holder.txtNome.setText(componentes.getNome());
        holder.txtIdade.setText(String.valueOf(componentes.getIdade()));
        holder.txtSexo.setText(componentes.isSexo() ? "Feminino" : "Masculino");
        holder.imgImage.setImageResource(componentes.isResultado() ? R.drawable.positivoicon : R.drawable.negativoicon);

        //configurando o layout que vai aparecer e desaparecer quando clicar
        if(componentes.isItensreduzidos()){
            holder.layout_ItensReduzidos.setVisibility(View.VISIBLE);
        } else holder.layout_ItensReduzidos.setVisibility(View.GONE);
        
        return convertView;
    }

    //classe para armazenar em java, cada componente da lista
        //sao os itens que vão sofrer alterações
    static class ViewHolder{
        TextView txtNome, txtIdade, txtSexo;
        ImageView imgImage;
        LinearLayout layout_ItensReduzidos;
    }
}
