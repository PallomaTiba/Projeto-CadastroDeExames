package com.example.provav2;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static android.text.TextUtils.isEmpty;

public class MainActivity extends AppCompatActivity {

    //declarando componentes layout
    EditText etNome, etIdade, etSexo;
    Button btnAdicionar, btnLimpar, btnEstatistica;
    RadioGroup rgResultado, rgSexo;
    RadioButton rbPositivo, rbFeminino;

    //declarando listview
    ListView listView;

    //declarando array
    ArrayList<Componentes> componentesArray;

    //declarando adaptador
    MyAdapter adapter;

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find views dos componentes:
        etNome = findViewById(R.id.etNome);
        etIdade = findViewById(R.id.etIdade);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        btnEstatistica = findViewById(R.id.btnEstatistica);
        btnLimpar = findViewById(R.id.btnLimpar);
        rgSexo = findViewById(R.id.rgSexo);
        rbFeminino = findViewById(R.id.rbFeminino);
        rgResultado = findViewById(R.id.rgResultado);
        rbPositivo = findViewById(R.id.rbPositivo);

        // find view da lista
        listView = findViewById(R.id.listView);
        
        //instanciando
        componentesArray = new ArrayList<>();

        //adaptador
        adapter = new MyAdapter(this, R.layout.row, componentesArray);
        //vincula lista ao adaptador
        listView.setAdapter(adapter);

        //menu de contexto
        registerForContextMenu(listView);
        
        context = this;


        // configurando o botao adicionar
        btnAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                //populando o array
                componentesArray.add(new Componentes(
                   etNome.getText().toString(),
                   Integer.parseInt(etIdade.getText().toString()),
                   rbFeminino.isChecked(),
                   rbPositivo.isChecked()

                ));
                //notificando o adaptador das mudanças
                    adapter.notifyDataSetChanged();



            }
        });

        //Configurando alternancia dos itens da lista
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Componentes componentes = componentesArray.get(position);
                componentes.setItensreduzidos( !(componentes.isItensreduzidos()));
                componentesArray.set(position, componentes);
                adapter.notifyDataSetChanged();
            }
        });

        // Configurando Botão Limpar a lista
        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //configurando a caixa de notificação

                AlertDialog.Builder builder = new AlertDialog.Builder (MainActivity.this);
                builder.setTitle("Excluir");
                builder.setMessage("Você deseja realmente LIMPAR a lista?");
                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // se sim : limpar componentes do array e notificar o adaptador
                        componentesArray.clear();
                        adapter.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), "Lista apagada!", Toast.LENGTH_LONG).show();
                    }

                });

                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Cancelado", Toast.LENGTH_LONG).show();

                    }
                });
                builder.show();

            }
        });

        //Configurando o Botão estatistica
        btnEstatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Oi professor, na atividade de estatistica eu nao consegui popular com as porcentagens,
                // acredito que o erro está no item "2" comentado abaixo, nao consegui filtrar os componentes
                // do array que são positivos, mas deixei o codigo do que eu estava tentando fazer pra voce ver (:


                //declarando o intent
                Intent intent = new Intent(MainActivity.this, EstatisticaActivity.class);

                //declarando as variaveis para calcular as porcentagens
                int TotalCOVIDPositivo = listView.getAdapter().getCount();
                float TotalPositivo = 0;
                int JovensPositivo = 0;
                int AdultosPositivo = 0;
                int IdososPositivo = 0;
                float pTotalCOVIDPositivo;
                float pJovensCOVIDPositivo;
                float pAdultosCOVIDPositivo;
                float pIdososCOVIDPositivo;


                // 1: o for para percorrer todos os itens da lista
                for (int p = 0; p<TotalCOVIDPositivo; p++){
                    // 2: um if para filtrar os itens da lista que estão positivos
                    if (componentesArray.get(p).isResultado() == true){
                        TotalPositivo = TotalPositivo +1; // variavel para armazenar o total de positivos
                        // 3: Os proximos 3 if para adicionar a uma variavel o total de positivos de cada faixa etária
                        if(componentesArray.get(p).getIdade() <= 19){
                            JovensPositivo = JovensPositivo + 1;
                        }
                        if(componentesArray.get(p).getIdade() > 19 && componentesArray.get(p).getIdade() < 60){
                            AdultosPositivo = AdultosPositivo + 1;
                        }
                        if(componentesArray.get(p).getIdade() >=60){
                            IdososPositivo = IdososPositivo + 1;
                        }


                    }


                }

                //calculo das porcentagens
                pTotalCOVIDPositivo = TotalPositivo/TotalCOVIDPositivo;
                pJovensCOVIDPositivo = JovensPositivo/TotalPositivo;
                pAdultosCOVIDPositivo  = AdultosPositivo/TotalPositivo;
                pIdososCOVIDPositivo  = IdososPositivo/TotalPositivo;



                if(componentesArray.isEmpty()){// Se a lista estiver vazia
                    intent.putExtra("pTotalCOVIDPositivo", 0*100*1.00f);
                    intent.putExtra("pJovensCOVIDPositivo", 0*100*1.00f);
                    intent.putExtra("pAdultosCOVIDPositivo", 0*100*1.00f);
                    intent.putExtra("pIdososCOVIDPositivo", 0*100*1.00f);

                } else{
                    intent.putExtra("pTotalCOVIDPositivo", pTotalCOVIDPositivo * 100 * 1.00f);
                    intent.putExtra("pJovensCOVIDPositivo", pJovensCOVIDPositivo * 100 * 1.00f);
                    intent.putExtra("pAdultosCOVIDPositivo", pAdultosCOVIDPositivo * 100 * 1.00f);
                    intent.putExtra("pIdososCOVIDPositivo", pIdososCOVIDPositivo * 100 * 1.00f);
                }

                //iniciando a atividade
                startActivity(intent);



/* Tentei fazer de outra forma mas nao deu :(

                // criando uma nova lista aplicando filtro pessoas com covid
                List<Componentes> CovidPositivo = componentesArray.stream().filter(Componentes::isItensreduzidos).collect(Collectors.toList());
                // .filter(Componentes::isItensreduzidos).collect( Collectors.toList() );

                // criando streams filtrando pessoas em diferentes faixas etárias usando a lista de pessoas com covid
                Stream<Componentes> streamJovensComCovid = CovidPositivo.stream().filter(componentesArray -> componentesArray.getIdade() <=19);
                Stream<Componentes> streamAdultosComCovid = CovidPositivo.stream().filter(componentesArray -> componentesArray.getIdade() >= 20 && componentesArray.getIdade() <= 59);
                Stream<Componentes> streamIdososComCovid = CovidPositivo.stream().filter(componentesArray -> componentesArray.getIdade() >= 60);

                // preparando intent com os dados para levar para a atividade de Estatística
                intent.putExtra("TotalCOVIDPositivo",
                        CovidPositivo.size() * 1.0f / ( componentesArray.size() == 0 ? 1 : componentesArray.size() ) * 100);

                intent.putExtra("JovensCOVIDPositivo",
                        streamJovensComCovid.count() * 1.0f / ( CovidPositivo.size() == 0 ? 1 : CovidPositivo.size() ) * 100);

                intent.putExtra("AdultosCOVIDPositivo",
                        streamAdultosComCovid.count() * 1.0f / ( CovidPositivo.size() == 0 ? 1 : CovidPositivo.size() )  * 100);

                intent.putExtra("IdososCOVIDPositivo",
                        streamIdososComCovid.count() * 1.0f / ( CovidPositivo.size() == 0 ? 1 : CovidPositivo.size() ) * 100);

                // inicializando atividade de Estatística
                startActivity(intent); */
            }


        });
    }




    //Configurando menu de contexto dos itens da lista
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflar = getMenuInflater();
        inflar.inflate(R.menu.menu,menu);
        menu.setHeaderTitle("Selecione");
    }

    //configurando o Excluir item do menu de contexto
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()){
            case R.id.ExcluirItem:
                componentesArray.remove(info.position);
                adapter.notifyDataSetChanged();
                return true;
            default:return super.onOptionsItemSelected(item);
        }
    }

}